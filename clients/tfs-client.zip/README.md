# CDC Code.json Metadata Client

## Purpose

This client is provided to CDC Code Owners to generate their repository-specific code.json file for SHARE IT Act compliance.

## Usage Instructions

1. Setup Python environment:

```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

2. Add your credentials to the provided .env file.

3. Execute your respective client:

```bash
python tfs_client.py --output myproject_code.json
```

4. Review your generated code.json.

5. Upload your code.json to the CDC shared location.
